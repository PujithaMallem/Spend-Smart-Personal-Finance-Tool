const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;
const JWT_SECRET = 'your_jwt_secret_key'; 
const SALT_ROUNDS = 10;

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

let users = [];
const dataFilePath = path.join(__dirname, 'data.json');

const logTimestamp = () => new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

try {
    if (fs.existsSync(dataFilePath)) {
        const rawData = fs.readFileSync(dataFilePath, 'utf8');
        const parsedData = JSON.parse(rawData);

        if (Array.isArray(parsedData)) {
            users = parsedData;
            console.log(`[${logTimestamp()}] data.json found with ${users.length} users.`);
        } else if (parsedData.users && Array.isArray(parsedData.users)) {
            console.log(`[${logTimestamp()}] Migrating old data.json format to new format.`);
            users = parsedData.users.map(user => ({
                username: user.username,
                email: user.email,
                password: user.password,
                income: parsedData.income || 0,
                budget: parsedData.budget || 0,
                expenses: parsedData.expenses || [],
                lastIncome: "",
                lastBudget: ""
            }));
            fs.writeFileSync(dataFilePath, JSON.stringify(users, null, 2), 'utf8');
            console.log(`[${logTimestamp()}] Migration complete. data.json now has ${users.length} users.`);
        } else {
            console.log(`[${logTimestamp()}] data.json is not in the expected format. Initializing empty user list.`);
            users = [];
            fs.writeFileSync(dataFilePath, JSON.stringify(users, null, 2), 'utf8');
        }
    } else {
        console.log(`[${logTimestamp()}] data.json not found. Initializing empty user list.`);
        users = [];
        fs.writeFileSync(dataFilePath, JSON.stringify(users, null, 2), 'utf8');
    }
} catch (error) {
    console.error(`[${logTimestamp()}] Error initializing data.json:`, error.message);
    users = [];
    fs.writeFileSync(dataFilePath, JSON.stringify(users, null, 2), 'utf8');
}

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

    if (!token) {
        console.log(`[${logTimestamp()}] Token missing in request to ${req.path}`);
        return res.status(401).json({ success: false, message: 'Token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            console.log(`[${logTimestamp()}] Invalid token for request to ${req.path}:`, err.message);
            return res.status(403).json({ success: false, message: 'Invalid token' });
        }
        req.user = user;
        next();
    });
};

const saveUsersToFile = () => {
    try {
        fs.writeFileSync(dataFilePath, JSON.stringify(users, null, 2), 'utf8');
        console.log(`[${logTimestamp()}] Successfully saved users to data.json.`);
    } catch (error) {
        console.error(`[${logTimestamp()}] Error saving to data.json:`, error.message);
        throw new Error('Failed to save user data');
    }
};

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    console.log(`[${logTimestamp()}] Login attempt for email: ${email}`);

    if (!email || !password) {
        console.log(`[${logTimestamp()}] Missing email or password in login request`);
        return res.status(400).json({ success: false, message: 'Email and password are required' });
    }

    const user = users.find(u => u.email === email);
    if (!user) {
        console.log(`[${logTimestamp()}] Invalid credentials for email: ${email}`);
        return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        console.log(`[${logTimestamp()}] Invalid credentials for email: ${email}`);
        return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const token = jwt.sign({ email: user.email }, JWT_SECRET, { expiresIn: '1h' });
    console.log(`[${logTimestamp()}] Login successful for email: ${email}`);
    res.json({ success: true, token });
});

app.post('/api/register', async (req, res) => {
    const { username, email, password } = req.body;
    console.log(`[${logTimestamp()}] Register attempt for email: ${email}`);

    if (!username || !email || !password) {
        console.log(`[${logTimestamp()}] Missing fields in register request`);
        return res.status(400).json({ success: false, message: 'Username, email, and password are required' });
    }

    if (users.find(u => u.email === email)) {
        console.log(`[${logTimestamp()}] Email already exists: ${email}`);
        return res.status(400).json({ success: false, message: 'Email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const newUser = {
        username,
        email,
        password: hashedPassword,
        income: 0,
        budget: 0,
        expenses: [],
        lastIncome: "",
        lastBudget: ""
    };
    users.push(newUser);
    saveUsersToFile();

    const token = jwt.sign({ email: newUser.email }, JWT_SECRET, { expiresIn: '1h' });
    console.log(`[${logTimestamp()}] User registered successfully: ${email}`);
    res.json({ success: true, message: 'User registered successfully', token });
});

app.get('/api/user', authenticateToken, (req, res) => {
    console.log(`[${logTimestamp()}] Fetching profile for email: ${req.user.email}`);
    const user = users.find(u => u.email === req.user.email);
    if (!user) {
        console.log(`[${logTimestamp()}] User not found: ${req.user.email}`);
        return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, user: { username: user.username, email: user.email } });
});

app.get('/api/user-data', authenticateToken, (req, res) => {
    console.log(`[${logTimestamp()}] Fetching user data for email: ${req.user.email}`);
    const user = users.find(u => u.email === req.user.email);
    if (!user) {
        console.log(`[${logTimestamp()}] User not found: ${req.user.email}`);
        return res.status(404).json({ success: false, message: 'User not found' });
    }

    const userData = {
        income: user.income || 0,
        budget: user.budget || 0,
        expenses: user.expenses || [],
        lastIncome: user.lastIncome || "",
        lastBudget: user.lastBudget || ""
    };

    console.log(`[${logTimestamp()}] Returning user data for email: ${req.user.email}:`, JSON.stringify(userData, null, 2));
    res.json({ success: true, data: userData });
});

app.post('/api/user-data', authenticateToken, (req, res) => {
    console.log(`[${logTimestamp()}] Updating user data for email: ${req.user.email}`);
    const userIndex = users.findIndex(u => u.email === req.user.email);
    if (userIndex === -1) {
        console.log(`[${logTimestamp()}] User not found: ${req.user.email}`);
        return res.status(404).json({ success: false, message: 'User not found' });
    }

    const { income, budget, expenses, lastIncome, lastBudget } = req.body;

    if (income !== undefined && (typeof income !== 'number' || income < 0)) {
        console.log(`[${logTimestamp()}] Invalid income value: ${income}`);
        return res.status(400).json({ success: false, message: 'Income must be a non-negative number' });
    }
    if (budget !== undefined && (typeof budget !== 'number' || budget < 0)) {
        console.log(`[${logTimestamp()}] Invalid budget value: ${budget}`);
        return res.status(400).json({ success: false, message: 'Budget must be a non-negative number' });
    }
    if (expenses !== undefined) {
        if (!Array.isArray(expenses)) {
            console.log(`[${logTimestamp()}] Invalid expenses format: not an array`);
            return res.status(400).json({ success: false, message: 'Expenses must be an array' });
        }
        for (const expense of expenses) {
            if (!expense.description || typeof expense.amount !== 'number' || expense.amount <= 0 || !expense.category || !expense.date) {
                console.log(`[${logTimestamp()}] Invalid expense entry:`, expense);
                return res.status(400).json({ success: false, message: 'Each expense must have a description, positive amount, category, and date' });
            }
        }
    }

    const updatedData = {
        income: income !== undefined ? income : (users[userIndex].income || 0),
        budget: budget !== undefined ? budget : (users[userIndex].budget || 0),
        expenses: expenses !== undefined ? expenses : (users[userIndex].expenses || []),
        lastIncome: lastIncome !== undefined ? lastIncome : (users[userIndex].lastIncome || ""),
        lastBudget: lastBudget !== undefined ? lastBudget : (users[userIndex].lastBudget || "")
    };
    console.log(`[${logTimestamp()}] Updating user data for email: ${req.user.email} with:`, JSON.stringify(updatedData, null, 2));

    users[userIndex] = {
        ...users[userIndex],
        ...updatedData
    };

    try {
        saveUsersToFile();
        console.log(`[${logTimestamp()}] User data updated successfully for email: ${req.user.email}`);
        res.json({ success: true, message: 'User data updated successfully' });
    } catch (error) {
        console.log(`[${logTimestamp()}] Failed to update user data for email: ${req.user.email}:`, error.message);
        res.status(500).json({ success: false, message: 'Failed to save user data' });
    }
});

app.post('/api/reset-data', authenticateToken, (req, res) => {
    console.log(`[${logTimestamp()}] Resetting user data for email: ${req.user.email}`);
    const userIndex = users.findIndex(u => u.email === req.user.email);
    if (userIndex === -1) {
        console.log(`[${logTimestamp()}] User not found: ${req.user.email}`);
        return res.status(404).json({ success: false, message: 'User not found' });
    }

    const resetData = {
        income: 0,
        budget: 0,
        expenses: [],
        lastIncome: "",
        lastBudget: ""
    };
    console.log(`[${logTimestamp()}] Resetting user data for email: ${req.user.email} to:`, JSON.stringify(resetData, null, 2));

    users[userIndex] = {
        ...users[userIndex],
        ...resetData
    };

    try {
        saveUsersToFile();
        console.log(`[${logTimestamp()}] User data reset successfully for email: ${req.user.email}`);
        res.json({ success: true, message: 'User data reset successfully' });
    } catch (error) {
        console.log(`[${logTimestamp()}] Failed to reset user data for email: ${req.user.email}:`, error.message);
        res.status(500).json({ success: false, message: 'Failed to reset user data' });
    }
});

app.listen(PORT, () => {
    console.log(`[${logTimestamp()}] Server running at http://localhost:${PORT}`);
});